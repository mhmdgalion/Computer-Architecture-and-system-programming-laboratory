#include <stdlib.h>
#include <stdio.h>
#include <string.h>


struct fun_desc {
  char *name;
  char (*fun)(char);
};

char censor(char c) {
  if(c == '!')
    return '*';
  else
    return c;
}
/* Gets a char c and returns its encrypted form by adding 2 to its value. 
        If c is not between 0x41 and 0x7a it is returned unchanged */
char encrypt(char c){
    if(c < 0x41 || c > 0x7a){
        return c;
    }
    return c+2;
}
/* Gets a char c and returns its decrypted form by reducing 2 to its value. 
        If c is not between 0x41 and 0x7a it is returned unchanged */
char decrypt(char c){
     if(c < 0x41 || c > 0x7a){
        return c;
    }
    return c-2;
} 
 /* Ignores c, reads and returns a character from stdin using fgetc. */
char my_get(char c){
    return fgetc(stdin);
}
 /* If c is a number between 0x41 and 0x7a, cprt prints the character of ASCII value c followed 
    by a new line. Otherwise, cprt prints the dot ('*') character. After printing, cprt returns 
        the value of c unchanged. */
char cprt(char c){
    if(c >= 0x41 && c <= 0x7a){
        printf("%c\n",c);
    }
    else{
        printf("%c\n",'*');
    }
    return c;
}
/* dprt prints the value of c in a decimal representation followed by a 
           new line, and returns c unchanged. */
char dprt(char c){
    int x = c - '0';
    printf("%d\n",x);
    return c;
}

 
char* map(char *array, int array_length, char (*f) (char)){
  char* mapped_array = (char*)(malloc(array_length*sizeof(char)));
  for(size_t i = 0 ;i < array_length;i++){
      mapped_array[i] = f(array[i]);
  }
  return mapped_array;
}
/* Gets a char c,  and if the char is 'q' , ends the program with exit code 0. Otherwise returns c. */
char quit(char c){
    if(c == 'q'){
        exit(0);
    }
    else{
        return c;
    }
    
}
void menupr(struct fun_desc men[]);

void menupr(struct fun_desc men[]){
    int i = 0;
    printf("please choose a function: \n");
    while(i < 7){
        printf("%d) %s\n",i,men[i].name);
        i++;
    }
}

int main(int argc, char **argv){
     struct fun_desc menu[] = { { "Censor", censor }, { "Encrypt", encrypt },{ "Decrypt", decrypt },{"Print dec", dprt},{ "Print string", cprt },{ "Get string", my_get }, {"Quit", quit} ,{ NULL, NULL } };
    int length = 6;
    int MaxLength = 1024;
    char carray[length];
    char op[MaxLength];
    while (1){
        menupr(menu);
        printf("Option: ");
        scanf("%s",op);
        fgetc(stdin);
        if(strcmp(op,"0") >= 0 && strcmp("6",op) >= 0){
            printf("Within bounds\n");
            if(strcmp(op,"6" )== 0){
                printf("quit\n");
            }

            
            int func_num = atoi(op);
            strcpy(carray,map(carray,length,menu[func_num].fun));
            printf("DONE\n\n");
        }else{
            printf("Not within bounds\n");
            exit(0);
        }
    }
}
