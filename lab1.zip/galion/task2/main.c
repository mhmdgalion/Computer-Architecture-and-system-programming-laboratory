#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int Debug=0;
int numOfDup=0;
int pos =0;
int neg = 0;
int c_old;
FILE* fileInput;
FILE* fileOutput;
FILE* fileErr;
char firstLetter = '\0';

int DupNumber(char c){// to a number
    if(c >='0' && c <='9') {
        return c - '0';
    }
    if(c >='A' && c <='F'){
        return c -'A'+10;
    }
    fprintf(stderr,"Error %c is not Hexi number\n",c);
    exit(0);
}
void getArguments(int argc,char **argv){
    for(int i=1;i<argc;i++){
        char arg[2];
        arg[0] =argv[i][0];
        arg[1] =argv[i][1];
        if(strcmp(argv[i],"-D") == 0){
            Debug = 1;
        }
        if(strcmp(arg,"-e") == 0 ){
            neg=1;
            numOfDup=DupNumber(argv[i][2]);
        }
        if(strcmp(arg ,"+e") == 0 ){
            pos=1;
            numOfDup= DupNumber(argv[i][2]);
        }

        if(strcmp(argv[i],"-i")&& strlen(argv[i]) > 2){
            fileInput=fopen(argv[i]+2,"r");
        }
        if(strcmp(arg,"-o")&& strlen(argv[i]) > 2){
            fileOutput=fopen(argv[i]+2,"a");
            fileErr = fopen(argv[i]+2,"a");
        }
        fprintf(stderr,"%s ",argv[i]);
    }
    fprintf(stderr,"\n");
}
int main(int argc,char **argv){
    fileInput=stdin;
    fileOutput=stdout;
    fileErr=stderr;
    getArguments(argc,argv);
    int counter=0;
    int c_new;
    if(neg == 1){
        for (int i = 0; i < numOfDup; i++)
            c_old = fgetc(fileInput);
    }
    while((c_old=fgetc(fileInput)) != EOF){
        if(firstLetter == '\0') {
            firstLetter = c_old;
        }
        c_new = c_old;
        if( c_old >='A' && c_old <='Z' ){ // capital to .
            c_new = '.';
            counter++;
        }
//        if(c_old == '\n'){
//            if(pos == 1 & neg == 0){
//                for(int i = 0; i < numOfEnc; i++) {
//                    fprintf(fileOutput,"%c",firstLetter);
//                }
//            }
//        }

        if(Debug == 1)
        {
            if(c_old !='\n'){
                fprintf(fileErr,"%d   %d\n",c_old,c_new);
            }
            else{
                fprintf(fileErr,"the number of letters: %d\n",counter);
                counter=0;
            }
        }
        fputc(c_new,fileOutput);
        if(c_old =='\n'){
            fflush(fileOutput);
            fflush(fileErr);
        }
    }

    if(pos == 1){
        for(int i = 0; i < numOfDup; i++) {
            fprintf(fileOutput,"%c",firstLetter);
        }
    }
    fclose(fileInput);
    fclose(fileOutput);
    fclose(fileErr);
}

