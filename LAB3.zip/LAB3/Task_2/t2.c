#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct link link;
typedef struct virus {
    unsigned short SigSize;
    char virusName[16];
    unsigned char* sig;
} virus;
struct link {
    link *nextVirus;
    virus *vir;
};

void kill_virus(char *fileName, int signatureOffset, int signatureSize);
void list_print(link *virus_list, FILE* output);
void list_free(link *virus_list);
void detect_virus(unsigned char *buffer, unsigned int size, link *virus_list);
link* list_append(link* virus_list, link* to_add);
link* case1(link* l);
void printVirus(virus* virus, FILE* output);
void PrintHex(FILE* output,unsigned char* buffer,int length);
void readVirus(virus* vir, FILE* input);
short CToShortL(char* bytes);
short CToShortL(char* bytes){
    return (bytes[1] << 8) | bytes[0];
}

int main(int argc, char const *argv[])
{
    FILE* f=NULL;
    link* l=NULL;
    while(1){
        printf("Please choose a function:\n1) Load signatures\n2) Print signatures\n3) Detect viruses\n4) Fix\n5) quit\n");
        char c[100]={'\0'};
        char c2[100]={'\0'};
        fgets(c, 100, stdin);
        int op=atoi(c);
            switch (op)
            {
            case 1:
                printf("enter file name: \n");
                l=case1(l);
                break;
            case 2:
                list_print(l,stdout);
                break;  
            case 3:
                fgets(c2, 100, stdin);
                sscanf(c2,"%s\n",c2);
                f=fopen(c2,"rb");
                unsigned char buffer[10000];
                size_t sizeOfBuffer=fread(buffer,sizeof(char),10000,f);
                detect_virus(buffer,sizeOfBuffer,l);
                fclose(f);
                break; 
            case 4:
            printf("please enter location\n");
                char tmp[100];
                fgets(tmp, 100, stdin);
                int location=atoi(tmp);
                printf("please enter signiture size\n");
                char tmp1[100];
                fgets(tmp1, 100, stdin);
                int size=atoi(tmp1);
                char tmp2[100];
                fgets(c2, 100, stdin);
                sscanf(c2,"%s\n",c2);
                f=fopen(c2,"rb");
                strcpy(tmp2,c2);
                kill_virus(tmp2,location,size);
                break;
                   
            case 5:
                printf("Not within bounds\n");
                if(l!=NULL) list_free(l);
                exit(0);
                break;        
            }
        }
        printf("\nDone\n");
    
    return 0;
}
void readVirus(virus* vir, FILE* input){
    char tmp[2];
    if(fread(tmp,sizeof(char),2,input)){
        printf("%02X %02X\n", tmp[0], tmp[1]);
        (vir->SigSize) = tmp[1]*256 +tmp[0];
        // printf("%d",vir->SigSize);
        vir->sig =malloc(vir->SigSize);
        fread(vir->sig,sizeof(char),vir->SigSize,input);
        fread(vir->virusName,sizeof(char),16,input);
    }
}

void printVirus(virus* virus, FILE* output){
    fprintf(output,"Virus name: %s\n",virus->virusName);
    fprintf(output,"Virus size: %d\n",virus->SigSize);
    fprintf(output,"signature:\n");
    PrintHex(output,virus->sig,virus->SigSize);
    fprintf(output,"\n\n");
}


void PrintHex(FILE* output, unsigned char* buffer,int length){
    for( int i =0; i < length ;i++){
        fprintf(output,"%02X ",buffer[i] & 0xff);
    }
}
// \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\2b

void list_print(link *virus_list, FILE* output){
  link* l = virus_list;
    while(l != NULL){
        printVirus(l->vir,output);
        l = l->nextVirus;
    }
}

link* list_append(link* virus_list, link* to_add){
    if(to_add->vir->SigSize ==0){
        free (to_add);
        return virus_list;
    }
    if(virus_list == NULL){
        return to_add;
    }
    to_add->nextVirus=virus_list;
    return virus_list;
}

void list_free(link *virus_list){
    link *tmp = virus_list;
    link *ptr =tmp;
    while(ptr){
    tmp =tmp->nextVirus;
    free(ptr->vir->sig);
    free(ptr->vir);
    free(ptr);
    ptr =tmp;
    }

}

void detect_virus(unsigned char *buffer, unsigned int size, link *virus_list){
  for(size_t i=0;i<size;++i){
        link* v=virus_list;
        while(v!=NULL){
            if(memcmp(buffer+i,v->vir->sig,v->vir->SigSize)==0){
            fprintf(stdout,"Location: %i\nVirus Name: %s\nthe size of Virus Signature: %i\n",i+1,v->vir->virusName,v->vir->SigSize);
            }
            v=v->nextVirus;
        }
    }
}
link* case1(link* l){
    char c[100];
    char c2[100];
    fgets(c, 100, stdin);
    sscanf(c,"%s\n",c2);
    FILE* f=fopen(c2,"rb");
    // printf("%s",c);
    if(f==NULL){
        perror("fopen");
        exit(0);
    }
    
    if(f!=NULL){
    while (!feof(f))
    {  
        link *m = malloc(sizeof(link));
        virus* vir =malloc(sizeof(virus));
        readVirus(vir,f);
        m->vir=vir;
        l=list_append(l,m);
    }
    fclose(f);
    }
    else
    {
        printf("No such file");
    }
    
    return l;
}

void kill_virus(char *fileName, int signitureOffset, int signitureSize){
 FILE *InfectedFile = fopen(fileName, "rb+");
    fseek(InfectedFile, signitureOffset-1, SEEK_SET);
    char *rep = "0x90";
    fwrite(rep, 1, signitureSize, InfectedFile);
    fclose(InfectedFile);
}