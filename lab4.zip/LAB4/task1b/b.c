#include "lab4_util.h"
#define WRITE 4
#define OPEN 5
#define DEFAULT 0640
#define CLOSE 6
#define STDERR 2
#define STDOUT 1
#define STDIN 0
#define READ 3
#define O_CREATE 64
#define O_WRONLY 1
#define O_RDONLY 0
#define EXIT 1
#define COD 0x55
extern int system_call();

int main(int argc, char** argv){
    int outFile = STDOUT;
    int inFile = STDIN;
    char* nameout;
    char *namein;
    int fd,debug = 0;
    int flagout,flaginp = 0;
    char buff[1] = "\n";
    int i;
    int count = 1;
    char c[1];
    int word =0;
    for(i = 0; i < argc; i++){
        if(!strncmp(argv[i], "-D",2))
            debug = 1;
        if(!strncmp(argv[i],"-o",2)){
            outFile = system_call(OPEN,argv[i]+2,O_CREATE | O_WRONLY, DEFAULT);
            nameout = argv[i]+2;
            flagout = 1;
        }
        if(!strncmp(argv[i], "-i",2)){
            inFile = system_call(OPEN,argv[i]+2,O_RDONLY, DEFAULT);
            namein = argv[i]+2;
            flaginp = 1;
        }       
    }
    if(debug && flagout){
        system_call(WRITE,STDERR,nameout,strlen(nameout));
        system_call(WRITE,STDERR,buff,1);
        system_call(WRITE,STDERR,"id:5\n",5);
        system_call(WRITE,STDERR,",value: ",8);
        system_call(WRITE,STDERR,itoa(outFile),1);
        system_call(WRITE,STDERR,buff,1);
    }
    if(debug && flaginp){
        system_call(WRITE,STDERR,namein,strlen(namein));
        system_call(WRITE,STDERR,buff,1);
        system_call(WRITE,STDERR,"id:5\n",5);
        system_call(WRITE,STDERR,",value: ",8);
        system_call(WRITE,STDERR,itoa(inFile),1);
        system_call(WRITE,STDERR,buff,1);
    }
    if(!flagout && debug)
        system_call(WRITE,STDERR,"stdout",6);
    if(!flaginp && debug)
        system_call(WRITE,STDERR,"stdin\n",6);
    while((fd = system_call(READ,inFile, c, 1)) > 0){
         if (word == 1 && c[0] == ' '){
            count++; 
         }
         if( c[0] == '\n'){
           system_call(WRITE,STDOUT, itoa(count), 1) ; 
         }
        if(debug && c[0] != '\n'){
            system_call(WRITE,STDERR,"id:3\n",5);
            system_call(WRITE,STDERR,",value: ",8);
            system_call(WRITE,STDERR,itoa(fd),1);
            system_call(WRITE,STDERR,buff,1);
        }
        if ((c[0] >= 'a' && c[0] <= 'z') || (c[0] >= 'A' && c[0] <= 'Z'))
         word = 1;
        else
         word = 0;
        if(fd <0 )
            system_call(EXIT,COD,0,0);
    }
    return 0;
}